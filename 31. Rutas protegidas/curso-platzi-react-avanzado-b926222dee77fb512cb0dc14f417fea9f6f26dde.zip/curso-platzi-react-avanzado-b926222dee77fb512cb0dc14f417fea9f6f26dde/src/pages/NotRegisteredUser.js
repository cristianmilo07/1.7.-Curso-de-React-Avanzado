import React from 'react'

export const NotRegisteredUser = () => (
  <h1>NotRegisteredUser</h1>
)
