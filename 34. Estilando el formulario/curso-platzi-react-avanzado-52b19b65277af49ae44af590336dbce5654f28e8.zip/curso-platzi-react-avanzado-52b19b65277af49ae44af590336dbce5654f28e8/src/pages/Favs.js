import React from 'react'

export const Favs = () => (
  <h1>Favs</h1>
)
