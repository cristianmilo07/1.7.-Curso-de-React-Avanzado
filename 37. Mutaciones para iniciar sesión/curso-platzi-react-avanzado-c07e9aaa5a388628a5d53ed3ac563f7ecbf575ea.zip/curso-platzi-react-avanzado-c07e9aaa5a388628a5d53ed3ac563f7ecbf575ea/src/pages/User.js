import React from 'react'

export const User = () => (
  <h1>User</h1>
)
