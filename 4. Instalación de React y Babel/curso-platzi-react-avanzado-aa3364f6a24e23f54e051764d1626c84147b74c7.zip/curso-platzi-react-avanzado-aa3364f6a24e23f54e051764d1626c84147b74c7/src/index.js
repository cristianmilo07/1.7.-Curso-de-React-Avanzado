import React from 'react'
import ReactDOM from 'react-dom'

ReactDOM.render(<h1>Seguimos con el curso avanzado!</h1>, document.getElementById('app'))