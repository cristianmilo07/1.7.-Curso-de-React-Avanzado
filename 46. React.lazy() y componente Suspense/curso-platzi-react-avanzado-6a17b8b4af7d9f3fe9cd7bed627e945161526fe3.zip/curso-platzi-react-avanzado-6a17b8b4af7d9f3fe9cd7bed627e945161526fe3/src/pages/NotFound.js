import React from 'react'

export const NotFound = () => (
  <h1>Esta página no existe! :(</h1>
)
