import React from 'react'
import { Category } from './components/Category'

export const App = () => (
  <Category />
)
